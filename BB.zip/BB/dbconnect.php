<?php

$server="localhost";
$user="root";
$passward="";
$db="bbdms";

$conn= new mysqli($server,$user,$passward,$db);

?>